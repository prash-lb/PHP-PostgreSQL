<!DOCTYPE html>
<?php
?>
<html>
<head>
	<title>Vidéo flex</title>
</head>
<body>
<h1> VidéoFlex</h1>
<center>
	<h2> Inscripton profil </h2>
	<form action="insertion_profil.php " method="post">
		

		<p>
			<label for ="nom">Nom</label>
			<input id="name" type = "varchar" name="lastname">
		</p>
		<p>
			<label for ="prenom">Prenom</label>
			<input id="fname" type = "varchar" name="firstname">
		
		</p>
		<p><input type ="submit" value="Enregistrer"></p></form>

	
</center>
</body>
</html>